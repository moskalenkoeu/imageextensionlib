Before using this plugin you need to agree with the ECW EULA (available as ECWEULA.txt) 
This plugin shall not be used within a server application to DECODE ECW format unless you have paid a licensing fee to Leica to use on a server.

